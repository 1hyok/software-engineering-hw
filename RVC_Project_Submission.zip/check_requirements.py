#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Project #3 과제 요구사항 자동 검증 스크립트
"""

import os
import re
import sys
from pathlib import Path

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    END = '\033[0m'
    BOLD = '\033[1m'

def print_header(text):
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.BLUE}{text}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.END}\n")

def print_success(text):
    print(f"{Colors.GREEN}✓ {text}{Colors.END}")

def print_error(text):
    print(f"{Colors.RED}✗ {text}{Colors.END}")

def print_warning(text):
    print(f"{Colors.YELLOW}⚠ {text}{Colors.END}")

def print_info(text):
    print(f"  {text}")

def check_unity_framework():
    """Unity 프레임워크 확인"""
    print_header("1. Unity 프레임워크 검증")
    
    unity_dir = Path("tests/unity")
    unity_h = unity_dir / "unity.h"
    unity_c = unity_dir / "unity.c"
    
    checks = {
        "unity.h 파일 존재": unity_h.exists(),
        "unity.c 파일 존재": unity_c.exists(),
    }
    
    if unity_h.exists():
        content = unity_h.read_text(encoding='utf-8')
        checks["UNITY_INT 타입 정의"] = "UNITY_INT" in content and "#define UNITY_INT" in content
        checks["UNITY_LINE_TYPE 타입 정의"] = "UNITY_LINE_TYPE" in content and "#define UNITY_LINE_TYPE" in content
        checks["UNITY_DISPLAY_STYLE_T enum 정의"] = "UNITY_DISPLAY_STYLE_T" in content
        checks["TEST_ASSERT_EQUAL_INT 매크로"] = "TEST_ASSERT_EQUAL_INT" in content
        checks["TEST_ASSERT_TRUE 매크로"] = "TEST_ASSERT_TRUE" in content
        checks["RUN_TEST 매크로"] = "RUN_TEST" in content
    
    all_pass = True
    for check, result in checks.items():
        if result:
            print_success(check)
        else:
            print_error(check)
            all_pass = False
    
    return all_pass

def count_test_functions(file_path):
    """테스트 파일에서 test_ 함수 개수 세기"""
    if not file_path.exists():
        return 0
    
    content = file_path.read_text(encoding='utf-8')
    # void test_ 로 시작하는 함수 찾기
    pattern = r'void\s+test_\w+\s*\([^)]*\)'
    matches = re.findall(pattern, content)
    return len(matches)

def check_unit_tests():
    """Unit Test 10개 확인"""
    print_header("2. Unit Test 검증")
    
    test_file = Path("tests/unit/test_unit.c")
    
    if not test_file.exists():
        print_error("test_unit.c 파일이 없습니다")
        return False
    
    count = count_test_functions(test_file)
    
    if count >= 10:
        print_success(f"Unit Test 개수: {count}개 (요구사항: 10개 이상)")
        return True
    else:
        print_error(f"Unit Test 개수: {count}개 (요구사항: 10개 이상)")
        return False

def check_integration_tests():
    """Integration Test 10개 확인"""
    print_header("3. Integration Test 검증")
    
    test_file = Path("tests/integration/test_integration.c")
    
    if not test_file.exists():
        print_error("test_integration.c 파일이 없습니다")
        return False
    
    count = count_test_functions(test_file)
    
    if count >= 10:
        print_success(f"Integration Test 개수: {count}개 (요구사항: 10개 이상)")
        return True
    else:
        print_error(f"Integration Test 개수: {count}개 (요구사항: 10개 이상)")
        return False

def check_system_tests():
    """System Test 10개 확인"""
    print_header("4. System Test 검증")
    
    test_file = Path("tests/system/test_system.c")
    
    if not test_file.exists():
        print_error("test_system.c 파일이 없습니다")
        return False
    
    count = count_test_functions(test_file)
    
    if count >= 10:
        print_success(f"System Test 개수: {count}개 (요구사항: 10개 이상)")
        return True
    else:
        print_error(f"System Test 개수: {count}개 (요구사항: 10개 이상)")
        return False

def check_test_harness():
    """Test Harness 확인"""
    print_header("5. Test Harness 검증")
    
    harness_h = Path("tests/test_harness.h")
    harness_c = Path("tests/test_harness.c")
    
    checks = {
        "test_harness.h 파일 존재": harness_h.exists(),
        "test_harness.c 파일 존재": harness_c.exists(),
    }
    
    if harness_h.exists():
        content = harness_h.read_text(encoding='utf-8')
        checks["test_harness_init 함수 선언"] = "test_harness_init" in content
        checks["test_harness_cleanup 함수 선언"] = "test_harness_cleanup" in content
    
    all_pass = True
    for check, result in checks.items():
        if result:
            print_success(check)
        else:
            print_error(check)
            all_pass = False
    
    return all_pass

def check_stubs():
    """Stub 구현 확인"""
    print_header("6. Stub 구현 검증")
    
    sensor_stub = Path("tests/stubs/sensor_stub.c")
    actuator_stub = Path("tests/stubs/actuator_stub.c")
    
    checks = {
        "sensor_stub.c 파일 존재": sensor_stub.exists(),
        "actuator_stub.c 파일 존재": actuator_stub.exists(),
    }
    
    all_pass = True
    for check, result in checks.items():
        if result:
            print_success(check)
        else:
            print_error(check)
            all_pass = False
    
    return all_pass

def check_drivers():
    """Driver 구현 확인"""
    print_header("7. Driver 구현 검증")
    
    driver_h = Path("tests/drivers/test_driver.h")
    driver_c = Path("tests/drivers/test_driver.c")
    
    checks = {
        "test_driver.h 파일 존재": driver_h.exists(),
        "test_driver.c 파일 존재": driver_c.exists(),
    }
    
    all_pass = True
    for check, result in checks.items():
        if result:
            print_success(check)
        else:
            print_error(check)
            all_pass = False
    
    return all_pass

def check_build_files():
    """빌드 파일 확인"""
    print_header("8. 빌드 파일 검증")
    
    build_bat = Path("tests/build_tests.bat")
    makefile = Path("tests/Makefile")
    test_runner = Path("tests/test_runner.c")
    
    checks = {
        "build_tests.bat 파일 존재 (Windows)": build_bat.exists(),
        "Makefile 파일 존재 (Linux/Mac)": makefile.exists(),
        "test_runner.c 파일 존재": test_runner.exists(),
    }
    
    all_pass = True
    for check, result in checks.items():
        if result:
            print_success(check)
        else:
            print_warning(check)
            # 빌드 파일은 필수는 아니므로 경고만
    
    return True  # 빌드 파일은 선택사항

def check_word_document():
    """Word 문서 확인"""
    print_header("9. Word 문서 검증")
    
    docx_file = Path("RVC_Test_Documentation.docx")
    
    if not docx_file.exists():
        print_error("RVC_Test_Documentation.docx 파일이 없습니다")
        print_info("Word 문서는 수동으로 확인해야 합니다:")
        print_info("  - 15장 이상인지 확인")
        print_info("  - 폰트 크기가 10 미만인지 확인")
        print_info("  - 다음 섹션이 포함되어 있는지:")
        print_info("    * Unity 프레임워크 선정 및 설명")
        print_info("    * Unit Test 10개 (내용 및 결과)")
        print_info("    * Integration Test 10개 (내용 및 결과)")
        print_info("    * System Test 10개 (내용 및 결과)")
        print_info("    * Driver, Stub, Test Harness 설명")
        return False
    
    print_success("RVC_Test_Documentation.docx 파일 존재")
    print_warning("Word 문서 내용은 수동으로 확인해야 합니다:")
    print_info("  - 15장 이상인지 확인")
    print_info("  - 폰트 크기가 10 미만인지 확인")
    print_info("  - 모든 섹션이 포함되어 있는지 확인")
    
    return True

def check_file_structure():
    """파일 구조 확인"""
    print_header("10. 파일 구조 검증")
    
    required_dirs = [
        "tests/unity",
        "tests/unit",
        "tests/integration",
        "tests/system",
        "tests/stubs",
        "tests/drivers",
    ]
    
    all_pass = True
    for dir_path in required_dirs:
        if Path(dir_path).exists():
            print_success(f"{dir_path}/ 디렉토리 존재")
        else:
            print_error(f"{dir_path}/ 디렉토리가 없습니다")
            all_pass = False
    
    return all_pass

def check_compilation():
    """컴파일 가능 여부 확인 (간단 체크)"""
    print_header("11. 컴파일 가능 여부 검증")
    
    unity_h = Path("tests/unity/unity.h")
    if not unity_h.exists():
        print_error("unity.h 파일이 없어 컴파일 확인 불가")
        return False
    
    # unity.h의 기본 문법 오류 체크
    content = unity_h.read_text(encoding='utf-8')
    
    checks = {
        "헤더 가드 존재": "#ifndef UNITY_H" in content and "#define UNITY_H" in content,
        "타입 정의 존재": "UNITY_INT" in content and "UNITY_LINE_TYPE" in content,
        "함수 선언 존재": "void UnityBegin" in content,
    }
    
    all_pass = True
    for check, result in checks.items():
        if result:
            print_success(check)
        else:
            print_error(check)
            all_pass = False
    
    if all_pass:
        print_info("실제 컴파일은 build_tests.bat 또는 Makefile을 사용하세요")
    
    return all_pass

def main():
    """메인 함수"""
    print_header("Project #3 과제 요구사항 자동 검증")
    
    # submission 디렉토리로 이동
    if Path("submission").exists():
        os.chdir("submission")
        print_info("submission 디렉토리로 이동했습니다")
    elif not Path("tests").exists():
        print_error("submission 디렉토리 또는 tests 디렉토리를 찾을 수 없습니다")
        print_info("이 스크립트는 submission 디렉토리에서 실행해야 합니다")
        sys.exit(1)
    
    results = []
    
    # 각 항목 검증
    results.append(("Unity 프레임워크", check_unity_framework()))
    results.append(("Unit Test", check_unit_tests()))
    results.append(("Integration Test", check_integration_tests()))
    results.append(("System Test", check_system_tests()))
    results.append(("Test Harness", check_test_harness()))
    results.append(("Stub 구현", check_stubs()))
    results.append(("Driver 구현", check_drivers()))
    results.append(("빌드 파일", check_build_files()))
    results.append(("Word 문서", check_word_document()))
    results.append(("파일 구조", check_file_structure()))
    results.append(("컴파일 가능", check_compilation()))
    
    # 최종 결과
    print_header("최종 검증 결과")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        if result:
            print_success(f"{name}: 통과")
        else:
            print_error(f"{name}: 실패")
    
    print(f"\n{Colors.BOLD}전체: {passed}/{total} 항목 통과{Colors.END}\n")
    
    if passed == total:
        print_success("모든 요구사항을 만족합니다! 🎉")
        return 0
    else:
        print_warning(f"{total - passed}개 항목이 아직 완료되지 않았습니다")
        return 1

if __name__ == "__main__":
    sys.exit(main())

